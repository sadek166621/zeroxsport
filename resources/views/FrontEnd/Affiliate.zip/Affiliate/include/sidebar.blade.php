{{-- resources/views/FrontEnd/Affiliate/include/sidebar.blade.php --}}
<div class="col-lg-3">
    {{-- Mobile Toggle Button --}}
    <div class="mobile-header d-lg-none d-flex justify-content-between align-items-center mb-3 px-2">
        <h5 class="mb-0">Menu</h5>
        <button class="mobile-toggle" type="button" data-bs-toggle="collapse" data-bs-target="#affiliateSidebar" aria-expanded="false" aria-controls="affiliateSidebar">
            <i class="bi bi-list fs-5"></i>
        </button>
    </div>

    {{-- Sidebar Content --}}
    <div class="collapse d-lg-block sidebar" id="affiliateSidebar">
        <div class="card shadow-sm border-0 rounded-4 bg-white p-3">

            {{-- Sidebar Items --}}
            <ul class="nav flex-column">
                <li class="nav-item mb-2">
                    <a href="{{ route('affiliate.dashboard') }}" class="sidebar-item {{ request()->routeIs('affiliate.dashboard') ? 'active' : '' }}">
                        <i class="bi bi-speedometer2"></i> <span>Dashboard</span>
                    </a>
                </li>

                <li class="nav-item mb-2">
                    <a href="{{ route('affiliate.profile') }}" class="sidebar-item {{ request()->routeIs('affiliate.profile') ? 'active' : '' }}">
                        <i class="bi bi-person-circle"></i> <span>Profile</span>
                    </a>
                </li>

                <li class="nav-item mb-2">
                    <a href="{{ route('affiliate.orders') }}" class="sidebar-item {{ request()->routeIs('affiliate.orders') ? 'active' : '' }}">
                        <i class="bi bi-cart3"></i> <span>Orders</span>
                    </a>
                </li>

                <li class="nav-item">
                    <form method="POST" action="{{ route('affiliate.logout') }}">
                        @csrf
                        <button type="submit" class="sidebar-item logout-item btn btn-link p-0 d-flex align-items-center">
                            <i class="bi bi-box-arrow-right"></i> <span>Logout</span>
                        </button>
                    </form>
                </li>
            </ul>

        </div>
    </div>
</div>
         <style>
                /* Sidebar styles copied from update-profile.html */
                .sidebar {
                    background: #fff;
                    border-radius: 18px;
                    box-shadow: 0 2px 16px rgba(44, 62, 80, 0.06);
                    padding: 1.5rem 1rem;
                    display: flex;
                    flex-direction: column;
                    align-items: flex-start;
                    gap: 0.5rem;
                }
                .sidebar-item {
                    display: flex;
                    align-items: center;
                    gap: 0.8rem;
                    padding: 0.8rem 1.2rem;
                    border-radius: 10px;
                    color: #6c757d;
                    background: none;
                    border: none;
                    font-weight: 500;
                    font-size: 1rem;
                    transition: background 0.2s, color 0.2s;
                    text-decoration: none;
                    width: 100%;
                }
                .sidebar-item.active, .sidebar-item:hover {
                    background: #ffe6e1; /* lighter shade for #DC452C */
                    color: #DC452C;
                }
                .sidebar-item i {
                    font-size: 1.2rem;
                }
                .logout-item {
                    color: #e74c3c !important;
                }
                .logout-item:hover {
                    background: #e74c3c !important;
                    color: #fff !important;
                }
                .mobile-header {
                    display: none;
                }
                .mobile-toggle {
                    background: #DC452C;
                    border: none;
                    color: #fff;
                    border-radius: 10px;
                    padding: 0.6rem 1.2rem;
                    font-weight: 500;
                    width: 100%;
                    transition: background 0.2s;
                }
                .mobile-toggle:hover, .mobile-toggle:focus {
                    background: #b33622;
                    color: #fff;
                }
                @media (max-width: 991.98px) {
                    .mobile-header {
                        display: block;
                        background: #fff;
                        border-radius: 12px;
                        padding: 0.7rem 1rem;
                        margin-bottom: 1rem;
                        box-shadow: 0 2px 8px rgba(44, 62, 80, 0.06);
                    }
                    .sidebar {
                        flex-direction: row;
                        justify-content: space-around;
                        align-items: center;
                        gap: 0;
                        padding: 1rem 0.5rem;
                    }
                    .sidebar-item span {
                        display: none;
                    }
                    .sidebar-item i {
                        font-size: 1.5rem;
                    }
                }
            </style>