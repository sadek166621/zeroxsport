<header class="card-header">
    <div class="row gx-3">
        <div class="col-lg-4 col-md-6 me-auto">
            <input type="text" placeholder="Search..." class="form-control" />
        </div>
        <div class="col-lg-2 col-6 col-md-3">
            <select class="form-select">
                <option>Status</option>
                <option>Active</option>
                <option>Disabled</option>
                <option>Show all</option>
            </select>
        </div>
        <div class="col-lg-2 col-6 col-md-3">
            <select class="form-select">
                <option>Show 20</option>
                <option>Show 30</option>
                <option>Show 40</option>
            </select>
        </div>
    </div>
</header>
<!-- card-header end// -->